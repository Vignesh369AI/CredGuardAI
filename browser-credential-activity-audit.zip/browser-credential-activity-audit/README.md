# Credential Activity Audit extension

This unpacked Manifest V3 extension works in Chromium browsers, including Google Chrome and Microsoft Edge. It records only local activity metadata. It is injected into ordinary matching pages and their frames, including about:blank child frames where the browser permits injection.

- `password_entry_started`: the first input into a password field after the page loads.
- `credential_form_submitted`: a form containing a password field was submitted.
- `possible_credential_entry_observed`: interaction with a control locally marked password-like from standard accessibility/autocomplete semantics. The semantic attribute values are never retained or sent.
- `nonstandard_editable_control_interaction_observed`: interaction with a text-like, editable control that might be an undisclosed custom credential field.
- `opaque_control_input_observed`: an input event retargeted from an opaque component, such as a closed shadow root. The extension cannot inspect that component's internals.
- `possible_credential_form_submitted`, `possible_credential_flow_action_observed`, and `possible_credential_flow_navigated`: potential submission/action/navigation following credential-like activity, including JavaScript-driven flows that do not fire a native form submission.

Each record includes an ISO-8601 timestamp, the **origin only** (for example, `https://example.com`), tab ID, frame ID, and a random browser-instance ID generated for this extension installation. It never accesses password values, username values, keyboard contents, field names, form contents, page paths, query strings, or fragments. It evaluates a limited set of semantic attributes locally to classify unusual controls, but never stores or transmits their values. The log remains in browser-local extension storage until cleared or exported.

## Coverage boundary

The detector is designed to avoid silently ignoring unusual web controls, not to make an impossible 100% guarantee. Browser security boundaries still exclude protected browser pages, disabled extensions, unsupported browsers, native applications, and any context the browser does not expose to extensions. Closed shadow-root internals cannot be read; this extension logs the exposed opaque input signal instead. Ambiguous signals are deliberately expected and are not proof that a password or other secret was entered.

## Windows logon-session limitation

Web extensions cannot access Windows account names, Windows logon session IDs, or another browser profile's session identity. The `browserInstanceId` is only a local pseudonymous identifier; it is not a Windows user/session identifier.

If Windows logon-session attribution is required for an authorized enterprise audit, collect it separately through approved endpoint/audit infrastructure and correlate using a policy-approved event identifier. Do not modify the extension to collect credentials or other form contents.

## Install locally

1. Open `chrome://extensions` in Chrome or `edge://extensions` in Edge.
2. Enable **Developer mode**.
3. Select **Load unpacked** and choose this folder.
4. Pin **Credential Activity Audit** and use its popup to view, export, or clear the local log.

Chrome and Edge will show a broad site-access warning because observing password-field activity requires the content script to run on pages. Review that permission with users before deployment.
