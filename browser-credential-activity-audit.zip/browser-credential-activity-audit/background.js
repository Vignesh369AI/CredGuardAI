const MAX_EVENTS = 1000;

async function getBrowserInstanceId() {
  const { browserInstanceId } = await chrome.storage.local.get("browserInstanceId");
  if (browserInstanceId) return browserInstanceId;

  const id = crypto.randomUUID();
  await chrome.storage.local.set({ browserInstanceId: id });
  return id;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== "credential-activity") return;

  (async () => {
    // Only metadata supplied below is accepted. Credentials, field names, form data,
    // query strings, and page paths are never requested or persisted.
    const tab = sender.tab;
    if (!tab?.id || !message.eventType || !message.origin) return;

    const { events = [] } = await chrome.storage.local.get("events");
    const event = {
      id: crypto.randomUUID(),
      eventType: message.eventType,
      occurredAt: new Date().toISOString(),
      origin: message.origin,
      tabId: tab.id,
      frameId: sender.frameId,
      browserInstanceId: await getBrowserInstanceId()
    };

    events.push(event);
    await chrome.storage.local.set({ events: events.slice(-MAX_EVENTS) });
    sendResponse({ ok: true });
  })();

  return true;
});
