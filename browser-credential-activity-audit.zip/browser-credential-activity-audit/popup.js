const eventContainer = document.getElementById("events");

function render(events) {
  if (!events.length) {
    eventContainer.innerHTML = '<p class="empty">No activity recorded yet.</p>';
    return;
  }
  const rows = [...events].reverse().map((event) => `
    <tr><td>${escapeHtml(event.occurredAt)}</td><td>${escapeHtml(event.eventType)}</td><td>${escapeHtml(event.origin)}</td><td title="Browser-local pseudonymous instance ID">${escapeHtml(event.browserInstanceId.slice(0, 8))}</td></tr>`).join("");
  eventContainer.innerHTML = `<table><thead><tr><th>Time</th><th>Activity</th><th>Site origin</th><th>Instance</th></tr></thead><tbody>${rows}</tbody></table>`;
}

function escapeHtml(value) {
  const node = document.createElement("span");
  node.textContent = String(value);
  return node.innerHTML;
}

async function load() {
  const { events = [] } = await chrome.storage.local.get("events");
  render(events);
}

document.getElementById("clear").addEventListener("click", async () => {
  await chrome.storage.local.set({ events: [] });
  await load();
});

document.getElementById("export").addEventListener("click", async () => {
  const { events = [] } = await chrome.storage.local.get("events");
  const blob = new Blob([JSON.stringify(events, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const anchor = Object.assign(document.createElement("a"), { href: url, download: "credential-activity-audit.json" });
  anchor.click();
  URL.revokeObjectURL(url);
});

load();
