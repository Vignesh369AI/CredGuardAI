// This script never reads input.value, input.name, form data, keystrokes, or text.
// It classifies UI controls locally and sends only a bounded event name and origin.
const activatedFields = new WeakSet();
let recentCredentialLikeActivity = false;
let flowActionReported = false;
let navigationReported = false;

const EDITABLE_INPUT_TYPES = new Set([
  "", "email", "number", "search", "tel", "text", "url"
]);

function attribute(element, name) {
  return element instanceof Element ? (element.getAttribute(name) || "").toLowerCase() : "";
}

function passwordField(element) {
  return element instanceof HTMLInputElement && element.type === "password";
}

function passwordAutocomplete(element) {
  return ["current-password", "new-password", "one-time-code"].includes(attribute(element, "autocomplete"));
}

function editableControl(element) {
  if (element instanceof HTMLInputElement) return EDITABLE_INPUT_TYPES.has(element.type);
  return element instanceof HTMLTextAreaElement || (element instanceof HTMLElement && element.isContentEditable);
}

function likelyCredentialSemantic(element) {
  // These attributes are inspected locally only; their contents are never stored or transmitted.
  const semantics = ["autocomplete", "aria-label", "placeholder", "role", "title"]
    .map((name) => attribute(element, name)).join(" ");
  return /password|passcode|\bpin\b|one.?time|verification|security.?code|credential/.test(semantics);
}

function report(eventType) {
  chrome.runtime.sendMessage({
    type: "credential-activity",
    eventType,
    // Origin deliberately omits pathname, query string, and fragment.
    origin: location.origin
  });
}

function observeEntry(target) {
  if (activatedFields.has(target)) return;
  activatedFields.add(target);

  if (passwordField(target)) {
    recentCredentialLikeActivity = true;
    report("password_entry_started");
  } else if (passwordAutocomplete(target) || likelyCredentialSemantic(target)) {
    recentCredentialLikeActivity = true;
    report("possible_credential_entry_observed");
  } else if (editableControl(target)) {
    // A text-like field can be a custom credential field. This intentionally has false positives
    // so that unknown credential controls produce a privacy-preserving correlation signal.
    recentCredentialLikeActivity = true;
    report("nonstandard_editable_control_interaction_observed");
  } else {
    // Input events from a closed shadow root are retargeted to the host. Its internals cannot be
    // inspected by an extension, but the event itself remains a useful ambiguous signal.
    report("opaque_control_input_observed");
  }
}

document.addEventListener("beforeinput", (event) => {
  observeEntry(event.target);
}, true);

document.addEventListener("input", (event) => {
  observeEntry(event.target);
}, true);

document.addEventListener("submit", (event) => {
  const form = event.target;
  if (!(form instanceof HTMLFormElement)) return;
  if (form.querySelector('input[type="password"]')) {
    report("credential_form_submitted");
  } else if (recentCredentialLikeActivity || form.querySelector("input, textarea, [contenteditable=true]")) {
    report("possible_credential_form_submitted");
  }
}, true);

document.addEventListener("click", (event) => {
  if (!recentCredentialLikeActivity || flowActionReported) return;
  const target = event.target instanceof Element ? event.target : null;
  const action = target?.closest("button, input[type=submit], input[type=button], [role=button]");
  if (!action) return;
  flowActionReported = true;
  report("possible_credential_flow_action_observed");
}, true);

addEventListener("pagehide", () => {
  if (recentCredentialLikeActivity && !navigationReported) {
    navigationReported = true;
    report("possible_credential_flow_navigated");
  }
}, true);
