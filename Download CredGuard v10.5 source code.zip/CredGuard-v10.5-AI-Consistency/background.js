"use strict";
const DEFAULT={mode:"detect",thresholds:{medium:40,high:75},actions:{low:"Detect",medium:"Detect",high:"Block"},allowlist:["microsoft.com","microsoftonline.com","office.com","live.com","github.com","google.com"],blocklist:[],brands:[{name:"microsoft",domains:["microsoft.com","microsoftonline.com","office.com","live.com"]},{name:"google",domains:["google.com","gmail.com"]},{name:"github",domains:["github.com"]},{name:"okta",domains:["okta.com"]}],regexRules:[{name:"Punycode hostname",target:"domain",pattern:"(^|\\.)xn--",score:75,action:"Detect",enabled:true},{name:"Authentication lure on suspicious TLD",target:"url",pattern:"(?:login|signin|auth|verify|secure).+\\.(?:xyz|top|click|site)(?:/|$)",score:45,action:"Detect",enabled:true}],telemetry:{maxEvents:500,entryCooldownSeconds:30,historyDays:7,includePath:true},ollama:{enabled:true,bridgeUrl:"http://127.0.0.1:8787",timeoutMs:3500,failMode:"local",minConfidence:65}};
async function getConfig(){const{config={}}=await chrome.storage.local.get('config');return{...DEFAULT,...config,thresholds:{...DEFAULT.thresholds,...config.thresholds},actions:{...DEFAULT.actions,...config.actions},telemetry:{...DEFAULT.telemetry,...config.telemetry},ollama:{...DEFAULT.ollama,...config.ollama}}}
const matches=(host,list=[])=>list.some(domain=>host===domain||host.endsWith('.'+domain));
const level=(score,c)=>score>=c.thresholds.high?'High':score>=c.thresholds.medium?'Medium':'Low';
function distance(a,b){const m=a.length,n=b.length,d=Array.from({length:m+1},()=>Array(n+1));for(let i=0;i<=m;i++)d[i][0]=i;for(let j=0;j<=n;j++)d[0][j]=j;for(let i=1;i<=m;i++)for(let j=1;j<=n;j++)d[i][j]=Math.min(d[i-1][j]+1,d[i][j-1]+1,d[i-1][j-1]+(a[i-1]===b[j-1]?0:1));return d[m][n]}
async function firstSeen(host,c){const{domainHistory={}}=await chrome.storage.local.get('domainHistory'),last=domainHistory[host],cutoff=Date.now()-c.telemetry.historyDays*86400000;domainHistory[host]=new Date().toISOString();await chrome.storage.local.set({domainHistory});return !last||Date.parse(last)<cutoff}
async function assess(payload,c){const u=new URL(payload.url),host=u.hostname.toLowerCase(),trusted=matches(host,c.allowlist),reasons=[],matchedRules=[];let score=0,forced=null;if(u.protocol!=='https:'){score+=30;reasons.push('HttpCredentialFlow')}if(host.includes('xn--')){score+=35;reasons.push('PunycodeHostname')}if(/^(?:\d{1,3}\.){3}\d{1,3}$/.test(host)){score+=45;reasons.push('IpLiteralHostname')}if(host.length>48){score+=12;reasons.push('LongHostname')}if(host.split('.').length-2>=4){score+=12;reasons.push('ExcessiveSubdomains')}if(/login|signin|auth|verify|secure|account|password/.test(host)){score+=18;reasons.push('AuthenticationTermInHostname')}if(/login|signin|auth|verify|secure|account|password/.test(u.pathname.toLowerCase())){score+=10;reasons.push('AuthenticationTermInPath')}score+=12;reasons.push('PasswordFieldObserved');if(payload.submitAttempt){score+=10;reasons.push('CredentialSubmissionAttempted')}const first=await firstSeen(host,c);if(first&&!trusted){score+=20;reasons.push('FirstCredentialEntryInLookback')}if(matches(host,c.blocklist)){score=100;forced='Block';reasons.push('ExplicitBlocklist')}for(const brand of c.brands||[]){if(host.includes(brand.name)&&!matches(host,brand.domains)){score+=40;reasons.push(`BrandOutsideApprovedDomain:${brand.name}`)}const label=host.split('.')[0].replace(/[-_]/g,'');if(label.length>=4&&distance(label,brand.name)<=2&&!matches(host,brand.domains)){score+=30;reasons.push(`BrandLookalike:${brand.name}`)}}for(const rule of c.regexRules||[]){if(!rule.enabled)continue;try{const value=rule.target==='domain'?host:`${u.origin}${u.pathname}`;if(new RegExp(rule.pattern,'i').test(value)){score+=Number(rule.score)||0;matchedRules.push(rule.name);reasons.push(`CustomRegex:${rule.name}`);if(rule.action==='Block')forced='Block'}}catch{reasons.push(`InvalidRegex:${rule.name}`)}}score=Math.min(100,trusted&&forced!=='Block'?Math.min(score,25):score);const risk=level(score,c);let action=c.mode==='prevent'?(forced||c.actions[risk.toLowerCase()]||'Detect'):'Detect';if(risk!=='High'&&forced!=='Block'&&action==='Block')action='Detect';return{u,host,trusted,first,score,risk,action,reasons,matchedRules}}

async function store(event,c){const{events=[]}=await chrome.storage.local.get({events:[]});if(event.ActionType==='CredentialEntryObserved'){const recently=events.find(x=>x.ActionType===event.ActionType&&x.RemoteDomain===event.RemoteDomain&&Date.now()-Date.parse(x.Timestamp)<c.telemetry.entryCooldownSeconds*1000);if(recently)return recently}events.unshift(event);events.splice(c.telemetry.maxEvents);await chrome.storage.local.set({events});return event}
function safePath(u,c){return c.telemetry.includePath?u.pathname.slice(0,180):''}

async function updateEventById(eventId, updater){
  const {events=[]}=await chrome.storage.local.get({events:[]});
  const index=events.findIndex(e=>e.EventId===eventId);
  if(index<0)return null;
  events[index]=typeof updater==='function'?updater({...events[index]}):{...events[index],...updater};
  await chrome.storage.local.set({events});
  return events[index];
}
function bridgeEndpoint(c,path){return c.ollama.bridgeUrl.replace(/\/$/,"")+path}
function mergeAIFields(event,patch){
  let additional={};try{additional=JSON.parse(event.AdditionalFields||'{}')}catch{}
  Object.assign(additional,{AIStatus:patch.AIStatus??event.AIStatus,OllamaStatus:patch.AIStatus??event.AIStatus,OllamaClassification:patch.AIClassification??event.AIClassification,OllamaConfidence:patch.AIConfidence??event.AIConfidence,OllamaReasoning:patch.AIReasoning??event.AIReasoning,OllamaModel:patch.AIModel??event.AIModel,OllamaLatencyMs:patch.AILatencyMs??event.AILatencyMs,OllamaRecommendedAction:patch.AIRecommendedAction??event.AIRecommendedAction,ClassificationSource:patch.ClassificationSource??event.ClassificationSource,AnalysisId:patch.AnalysisId??event.AnalysisId});
  return {...event,...patch,AdditionalFields:JSON.stringify(additional)};
}
async function enqueueAI(event,r,payload,c){
  if(!c.ollama.enabled)return updateEventById(event.EventId,e=>mergeAIFields(e,{AIStatus:'Disabled',AIClassification:'Not enriched',AIConfidence:null,AIReasoning:'Ollama enrichment disabled',AILatencyMs:null,ClassificationSource:'Deterministic'}));
  try{
    const request={eventId:event.EventId,actionType:event.ActionType,signal:{domain:r.host,path:safePath(r.u,c),protocol:r.u.protocol,firstCredentialEntryInLookback:r.first,passwordFieldCount:payload.passwordFieldCount},deterministic:{score:r.score,risk:r.risk,reasons:r.reasons.slice(0,8),matchedRules:r.matchedRules.slice(0,8),trusted:r.trusted}};
    const healthResponse=await fetch(bridgeEndpoint(c,'/health'));
    const health=await healthResponse.json();
    if(!healthResponse.ok||health.apiVersion!=='2.0')throw Error('IncompatibleBridge: stop the old port 8787 process and start the v10.3 ollama-bridge');
    const response=await fetch(bridgeEndpoint(c,'/enqueue'),{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(request)});
    const data=await response.json();
    if(!response.ok)throw Error(data.error||`BridgeHttp${response.status}`);
    const result=data.result;
    return updateEventById(event.EventId,e=>mergeAIFields(e,{AnalysisId:data.analysisId,AIStatus:data.status,AIClassification:result?.classification||'Pending',AIConfidence:result?.confidence??null,AIReasoning:result?.reasoning||'Queued in Ollama bridge',AIModel:result?.model||null,AILatencyMs:result?.latencyMs??null,AIRecommendedAction:result?.recommendedAction||null,ClassificationSource:result?.source||'Deterministic'}));
  }catch(error){
    return updateEventById(event.EventId,e=>mergeAIFields(e,{AIStatus:'Failed',AIClassification:'Unknown',AIConfidence:null,AIReasoning:String(error.message||error),AILatencyMs:null,ClassificationSource:'Deterministic'}));
  }
}
async function refreshAIResults(c){
  const {events=[]}=await chrome.storage.local.get({events:[]});let changed=false;
  for(let i=0;i<events.length;i++){
    const event=events[i];if(!event.AnalysisId||!['Pending','Running'].includes(event.AIStatus))continue;
    try{
      const response=await fetch(bridgeEndpoint(c,`/result/${encodeURIComponent(event.AnalysisId)}`));if(!response.ok)continue;
      const data=await response.json();const result=data.result;
      const patch={AIStatus:data.status,AIClassification:result?.classification||event.AIClassification,AIConfidence:result?.confidence??event.AIConfidence,AIReasoning:data.error||result?.reasoning||event.AIReasoning,AIModel:result?.model||event.AIModel,AILatencyMs:result?.latencyMs??event.AILatencyMs,AIRecommendedAction:result?.recommendedAction||event.AIRecommendedAction,ClassificationSource:result?.source||event.ClassificationSource};
      events[i]=mergeAIFields(event,patch);changed=true;
    }catch{}
  }
  if(changed)await chrome.storage.local.set({events});return events;
}
async function retryAI(event,c){
  let additional={};try{additional=JSON.parse(event.AdditionalFields||'{}')}catch{}
  const r={host:event.RemoteDomain,u:new URL(event.RemoteUrl),first:!!additional.FirstCredentialEntryInLookback,trusted:!!additional.TrustedDomain,score:event.RiskScore,risk:event.RiskLevel,reasons:additional.ReasonCodes||[],matchedRules:additional.MatchedRules||[]};
  await updateEventById(event.EventId,e=>mergeAIFields(e,{AnalysisId:null,AIStatus:'Pending',AIClassification:'Pending',AIConfidence:null,AIReasoning:'Retry queued',AILatencyMs:null,ClassificationSource:'Deterministic'}));
  return enqueueAI(event,r,{passwordFieldCount:additional.PasswordFieldCount||0},c);
}
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
  (async()=>{
    if(message.type==='CREDGUARD_EVALUATE'){
      const c=await getConfig(),r=await assess(message.payload,c),timestamp=new Date().toISOString(),eventId=crypto.randomUUID();
      const actionType=r.action==='Block'&&message.payload.submitAttempt?'CredentialSubmissionBlocked':message.payload.eventType;
      const additional={SchemaVersion:'2.2',EventId:eventId,RiskLevel:r.risk,RiskScore:r.score,EnforcementAction:r.action,RuleSource:'CredGuardDeterministic',MatchedRules:r.matchedRules,ReasonCodes:r.reasons,TrustedDomain:r.trusted,FirstCredentialEntryInLookback:r.first,Origin:r.u.origin,Path:safePath(r.u,c),PasswordFieldCount:message.payload.passwordFieldCount,IsTopFrame:message.payload.isTopFrame,AIStatus:c.ollama.enabled?'Pending':'Disabled',ClassificationSource:'Deterministic',Privacy:'No usernames, passwords, keystrokes, form values, cookies, session tokens, query values, raw page text, screenshots, or HTML collected'};
      const event={EventId:eventId,Timestamp:timestamp,ActionType:actionType,RemoteUrl:r.u.origin,RemoteDomain:r.host,RiskLevel:r.risk,RiskScore:r.score,EnforcementAction:r.action,AIStatus:c.ollama.enabled?'Pending':'Disabled',AIClassification:c.ollama.enabled?'Pending':'Not enriched',AIConfidence:null,AIReasoning:c.ollama.enabled?'Submitting to Ollama bridge':'Ollama enrichment disabled',AIModel:null,AILatencyMs:null,AIRecommendedAction:null,ClassificationSource:'Deterministic',Summary:`${r.risk}-confidence credential activity on ${r.host}.`,AdditionalFields:JSON.stringify(additional)};
      await store(event,c);
      await enqueueAI(event,r,message.payload,c);
      return event;
    }
    if(message.type==='GET_DATA'){const c=await getConfig(),events=await refreshAIResults(c);return{config:c,events}}
    if(message.type==='SAVE_CONFIG'){await chrome.storage.local.set({config:message.config});return{ok:true}}
    if(message.type==='CLEAR_EVENTS'){await chrome.storage.local.set({events:[]});return{ok:true}}
    if(message.type==='RETRY_AI'){const c=await getConfig(),{events=[]}=await chrome.storage.local.get({events:[]}),event=events.find(x=>x.EventId===message.eventId);if(!event)throw Error('EventNotFound');await retryAI(event,c);return{ok:true}}
    if(message.type==='EXPORT_EVENTS'){const c=await getConfig(),events=await refreshAIResults(c),jsonl=events.map(x=>JSON.stringify(x)).join('\n'),bytes=new TextEncoder().encode(jsonl);let binary='';for(let i=0;i<bytes.length;i+=32768)binary+=String.fromCharCode(...bytes.subarray(i,i+32768));const url='data:application/x-ndjson;base64,'+btoa(binary);await chrome.downloads.download({url,filename:'CredGuard-events.jsonl',saveAs:true});return{ok:true,count:events.length}}
  })().then(reply).catch(error=>reply({error:error.message}));return true;
});
