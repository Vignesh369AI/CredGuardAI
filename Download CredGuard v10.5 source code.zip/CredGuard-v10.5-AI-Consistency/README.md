# CredGuard v10.5 AI Consistency

Existing v10 UI and extension functionality are unchanged. AI-only changes: confidence below 70 always maps to Unknown; guarded Phishing requires deterministic score 60 or higher; rawClassification and guardrailReason remain available in bridge results. No domains were added to trusted lists.
